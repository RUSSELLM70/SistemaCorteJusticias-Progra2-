--
-- Database: `cortejusticia`
--

create schema cortejusticia;
use cortejusticia;

-- --------------------------------------------------------

--
-- Table structure for table `jueces`
--

CREATE TABLE `jueces` (
  `cedula` varchar(20) NOT NULL primary key,
  `usuario` varchar(20) NOT NULL,
  `clave` varchar(10) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `apellidos` varchar(40) NOT NULL,
  `telefono` varchar(10) NOT NULL,
  `sala` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `querellante`
--

CREATE TABLE `querellantes` (
  `cedula` varchar(20) NOT NULL primary key, 
  `nombre` varchar(20) NOT NULL,
  `apellidos` varchar(40) NOT NULL,
  `direccion` varchar(20) NOT NULL,
  `telefono` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `secretario`
--

CREATE TABLE `secretarios` (
  `usuario` varchar(20) NOT NULL primary key,
  `clave` varchar(10) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `apellidos` varchar(40) NOT NULL,
  `telefono` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `casos`
--

CREATE TABLE `casos` (
  `numero` INT NOT NULL auto_increment primary key,
  `descripcion` varchar(2000) NOT NULL,
  `estado` varchar(10) NOT NULL,
  `fecha`  TIMESTAMP NOT NULL,
  `cedulaquerellante` varchar(20) NOT NULL,
  `cedulajuez` varchar(20) DEFAULT NULL,
  `detalle` varchar(1000) DEFAULT NULL,
  FOREIGN KEY fk_QUERELLANTE(cedulaquerellante)
	REFERENCES querellantes(cedula)
	ON UPDATE CASCADE
	ON DELETE RESTRICT,
  FOREIGN KEY fk_JUEZ(cedulajuez)
	REFERENCES jueces(cedula)
	ON UPDATE CASCADE
	ON DELETE RESTRICT
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `historialcasos`
--

CREATE TABLE `historialcasos` (
	`numerocaso` int(11) NOT NULL, 
	`fechacambio` TIMESTAMP NOT NULL,
	`estado` varchar(10) NOT NULL,
	primary key (numerocaso, fechacambio),
	FOREIGN KEY fk_caso(numerocaso)
	REFERENCES casos(numero)
	ON UPDATE CASCADE
	ON DELETE RESTRICT   
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `usuarioycasoactual`
--

CREATE TABLE `usuarioycasoactual`(
id varchar(20) NOT NULL primary key,
numero int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO usuarioycasoactual(id, numero)
VALUE('01', 1);