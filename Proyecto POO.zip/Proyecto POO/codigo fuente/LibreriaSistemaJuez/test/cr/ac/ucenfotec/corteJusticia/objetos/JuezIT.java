/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cr.ac.ucenfotec.corteJusticia.objetos;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ROLANDO
 */
public class JuezIT {

    public JuezIT() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getCedula method, of class Juez.
     */
    @Test
    public void testGetCedula() {
        System.out.println("getCedula");
        Juez instance = new Juez();
        String expResult = "";
        String result = instance.getCedula();
        assertEquals(expResult, result);

    }

    /**
     * Test of setCedula method, of class Juez.
     */
    @Test
    public void testSetCedula() {
        System.out.println("setCedula");
        String cedula = "";
        Juez instance = new Juez();
        instance.setCedula(cedula);

    }

    /**
     * Test of getUsuario method, of class Juez.
     */
    @Test
    public void testGetUsuario() {
        System.out.println("getUsuario");
        Juez instance = new Juez();
        String expResult = "";
        String result = instance.getUsuario();
        assertEquals(expResult, result);

    }

    /**
     * Test of setUsuario method, of class Juez.
     */
    @Test
    public void testSetUsuario() {
        System.out.println("setUsuario");
        String usuario = "";
        Juez instance = new Juez();
        instance.setUsuario(usuario);

    }

    /**
     * Test of getClave method, of class Juez.
     */
    @Test
    public void testGetClave() {
        System.out.println("getClave");
        Juez instance = new Juez();
        String expResult = "";
        String result = instance.getClave();
        assertEquals(expResult, result);

    }

    /**
     * Test of setClave method, of class Juez.
     */
    @Test
    public void testSetClave() {
        System.out.println("setClave");
        String clave = "";
        Juez instance = new Juez();
        instance.setClave(clave);

    }

    /**
     * Test of getSala method, of class Juez.
     */
    @Test
    public void testGetSala() {
        System.out.println("getSala");
        Juez instance = new Juez();
        String expResult = "";
        String result = instance.getSala();
        assertEquals(expResult, result);

    }

    /**
     * Test of setSala method, of class Juez.
     */
    @Test
    public void testSetSala() {
        System.out.println("setSala");
        String sala = "";
        Juez instance = new Juez();
        instance.setSala(sala);

    }

    /**
     * Test of toString method, of class Juez.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Juez instance = new Juez();
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);

    }

}
