/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cr.ac.ucenfotec.corteJusticia.objetos;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ROLANDO
 */
public class QuerellanteIT {

    public QuerellanteIT() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getCedula method, of class Querellante.
     */
    @Test
    public void testGetCedula() {
        System.out.println("getCedula");
        Querellante instance = new Querellante();
        String expResult = "";
        String result = instance.getCedula();
        assertEquals(expResult, result);

    }

    /**
     * Test of setCedula method, of class Querellante.
     */
    @Test
    public void testSetCedula() {
        System.out.println("setCedula");
        String cedula = "";
        Querellante instance = new Querellante();
        instance.setCedula(cedula);

    }

    /**
     * Test of getDireccion method, of class Querellante.
     */
    @Test
    public void testGetDireccion() {
        System.out.println("getDireccion");
        Querellante instance = new Querellante();
        String expResult = "";
        String result = instance.getDireccion();
        assertEquals(expResult, result);

    }

    /**
     * Test of setDireccion method, of class Querellante.
     */
    @Test
    public void testSetDireccion() {
        System.out.println("setDireccion");
        String direccion = "";
        Querellante instance = new Querellante();
        instance.setDireccion(direccion);

    }

    /**
     * Test of toString method, of class Querellante.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Querellante instance = new Querellante();
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);

    }

}
