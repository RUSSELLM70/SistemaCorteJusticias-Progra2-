/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cr.ac.ucenfotec.corteJusticia.multis;

import cr.ac.ucenfotec.corteJusticia.objetos.Caso;
import cr.ac.ucenfotec.corteJusticia.objetos.HistorialCaso;
import java.time.LocalDateTime;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ROLANDO
 */
public class MultiCasoIT {

    public MultiCasoIT() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of guardar method, of class MultiCaso.
     */
    @Test
    public void testGuardar() throws Exception {
        System.out.println("guardar");
        String descripcion = "";
        MultiCaso instance = new MultiCaso();
        instance.guardar(descripcion);

    }

    /**
     * Test of guardarSecretario method, of class MultiCaso.
     */
    @Test
    public void testGuardarSecretario() throws Exception {
        System.out.println("guardarSecretario");
        String descripcion = "";
        String cedulaQuerellante = "";
        MultiCaso instance = new MultiCaso();
        instance.guardarSecretario(descripcion, cedulaQuerellante);

    }

    /**
     * Test of listarCasosJuez method, of class MultiCaso.
     */
    @Test
    public void testListarCasosJuez() throws Exception {
        System.out.println("listarCasosJuez");
        MultiCaso instance = new MultiCaso();
        ArrayList<Caso> expResult = null;
        ArrayList<Caso> result = instance.listarCasosJuez();
        assertEquals(expResult, result);

    }

    /**
     * Test of listarCasosQuerellante method, of class MultiCaso.
     */
    @Test
    public void testListarCasosQuerellante() throws Exception {
        System.out.println("listarCasosQuerellante");
        MultiCaso instance = new MultiCaso();
        ArrayList<Caso> expResult = null;
        ArrayList<Caso> result = instance.listarCasosQuerellante();
        assertEquals(expResult, result);

    }

    /**
     * Test of comprobarRegistro method, of class MultiCaso.
     */
    @Test
    public void testComprobarRegistro() throws Exception {
        System.out.println("comprobarRegistro");
        int numero = 0;
        MultiCaso instance = new MultiCaso();
        boolean expResult = false;
        boolean result = instance.comprobarRegistro(numero);
        assertEquals(expResult, result);

    }

    /**
     * Test of actulizarCaso method, of class MultiCaso.
     */
    @Test
    public void testActulizarCaso() throws Exception {
        System.out.println("actulizarCaso");
        String estado = "";
        String detalle = "";
        MultiCaso instance = new MultiCaso();
        instance.actulizarCaso(estado, detalle);

    }

    /**
     * Test of registrarHistorial method, of class MultiCaso.
     */
    @Test
    public void testRegistrarHistorial_3args() throws Exception {
        System.out.println("registrarHistorial");
        int numero = 0;
        String estado = "";
        LocalDateTime fecha = null;
        MultiCaso instance = new MultiCaso();
        instance.registrarHistorial(numero, estado, fecha);

    }

    /**
     * Test of registrarHistorial method, of class MultiCaso.
     */
    @Test
    public void testRegistrarHistorial_String() throws Exception {
        System.out.println("registrarHistorial");
        String estado = "";
        MultiCaso instance = new MultiCaso();
        instance.registrarHistorial(estado);

    }

    /**
     * Test of buscarEstado method, of class MultiCaso.
     */
    @Test
    public void testBuscarEstado() throws Exception {
        System.out.println("buscarEstado");
        MultiCaso instance = new MultiCaso();
        String expResult = "";
        String result = instance.buscarEstado();
        assertEquals(expResult, result);

    }

    /**
     * Test of buscarNumeroCaso method, of class MultiCaso.
     */
    @Test
    public void testBuscarNumeroCaso() throws Exception {
        System.out.println("buscarNumeroCaso");
        MultiCaso instance = new MultiCaso();
        int expResult = 0;
        int result = instance.buscarNumeroCaso();
        assertEquals(expResult, result);

    }

    /**
     * Test of listarHistorialCaso method, of class MultiCaso.
     */
    @Test
    public void testListarHistorialCaso() throws Exception {
        System.out.println("listarHistorialCaso");
        MultiCaso instance = new MultiCaso();
        ArrayList<HistorialCaso> expResult = null;
        ArrayList<HistorialCaso> result = instance.listarHistorialCaso();
        assertEquals(expResult, result);

    }

}
