/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cr.ac.ucenfotec.corteJusticia.multis;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ROLANDO
 */
public class MultiSecretarioIT {

    public MultiSecretarioIT() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of guardar method, of class MultiSecretario.
     */
    @Test
    public void testGuardar() throws Exception {
        System.out.println("guardar");
        String clave = "";
        String usuario = "";
        String nombre = "";
        String apellidos = "";
        String telefono = "";
        MultiSecretario instance = new MultiSecretario();
        instance.guardar(clave, usuario, nombre, apellidos, telefono);

    }

    /**
     * Test of comprobarRegistro method, of class MultiSecretario.
     */
    @Test
    public void testComprobarRegistro() throws Exception {
        System.out.println("comprobarRegistro");
        String usuario = "";
        MultiSecretario instance = new MultiSecretario();
        boolean expResult = false;
        boolean result = instance.comprobarRegistro(usuario);
        assertEquals(expResult, result);

    }

    /**
     * Test of verificarDatosLogin method, of class MultiSecretario.
     */
    @Test
    public void testVerificarDatosLogin() throws Exception {
        System.out.println("verificarDatosLogin");
        String usuario = "";
        String clave = "";
        MultiSecretario instance = new MultiSecretario();
        boolean expResult = false;
        boolean result = instance.verificarDatosLogin(usuario, clave);
        assertEquals(expResult, result);

    }

}
