/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cr.ac.ucenfotec.corteJusticia.multis;

import cr.ac.ucenfotec.corteJusticia.objetos.Juez;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ROLANDO
 */
public class MultiJuezIT {

    public MultiJuezIT() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of guardar method, of class MultiJuez.
     */
    @Test
    public void testGuardar() throws Exception {
        System.out.println("guardar");
        String cedula = "";
        String usuario = "";
        String clave = "";
        String nombre = "";
        String apellidos = "";
        String telefono = "";
        String sala = "";
        MultiJuez instance = new MultiJuez();
        instance.guardar(cedula, usuario, clave, nombre, apellidos, telefono, sala);

    }

    /**
     * Test of comprobarRegistro method, of class MultiJuez.
     */
    @Test
    public void testComprobarRegistro() throws Exception {
        System.out.println("comprobarRegistro");
        String cedula = "";
        MultiJuez instance = new MultiJuez();
        boolean expResult = false;
        boolean result = instance.comprobarRegistro(cedula);
        assertEquals(expResult, result);

    }

    /**
     * Test of comprobarUsuario method, of class MultiJuez.
     */
    @Test
    public void testComprobarUsuario() throws Exception {
        System.out.println("comprobarUsuario");
        String usuario = "";
        MultiJuez instance = new MultiJuez();
        boolean expResult = false;
        boolean result = instance.comprobarUsuario(usuario);
        assertEquals(expResult, result);

    }

    /**
     * Test of verificarDatosLogin method, of class MultiJuez.
     */
    @Test
    public void testVerificarDatosLogin() throws Exception {
        System.out.println("verificarDatosLogin");
        String usuario = "";
        String clave = "";
        MultiJuez instance = new MultiJuez();
        boolean expResult = false;
        boolean result = instance.verificarDatosLogin(usuario, clave);
        assertEquals(expResult, result);

    }

    /**
     * Test of buscar method, of class MultiJuez.
     */
    @Test
    public void testBuscar() throws Exception {
        System.out.println("buscar");
        MultiJuez instance = new MultiJuez();
        Juez expResult = null;
        Juez result = instance.buscar();
        assertEquals(expResult, result);

    }

}
