/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cr.ac.ucenfotec.corteJusticia.gestores;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ROLANDO
 */
public class GestorSecretarioIT {
    
    public GestorSecretarioIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of agregarSecretario method, of class GestorSecretario.
     */
    @Test
    public void testAgregarSecretario() throws Exception {
        System.out.println("agregarSecretario");
        String clave = "";
        String usuario = "";
        String nombre = "";
        String apellidos = "";
        String telefono = "";
        GestorSecretario instance = new GestorSecretario();
//        instance.agregarSecretario(clave, usuario, nombre, apellidos, telefono);

    }

    /**
     * Test of comprobarRegistroUsuario method, of class GestorSecretario.
     */
    @Test
    public void testComprobarRegistroUsuario() throws Exception {
        System.out.println("comprobarRegistroUsuario");
        String usuario = "";
        GestorSecretario instance = new GestorSecretario();
        boolean expResult = false;
        boolean result = instance.comprobarRegistroUsuario(usuario);
        assertEquals(expResult, result);

    }

    /**
     * Test of verificarDatosLogin method, of class GestorSecretario.
     */
    @Test
    public void testVerificarDatosLogin() throws Exception {
        System.out.println("verificarDatosLogin");
        String usuario = "";
        String clave = "";
        GestorSecretario instance = new GestorSecretario();
        boolean expResult = false;
        boolean result = instance.verificarDatosLogin(usuario, clave);
        assertEquals(expResult, result);
    }
    
}
