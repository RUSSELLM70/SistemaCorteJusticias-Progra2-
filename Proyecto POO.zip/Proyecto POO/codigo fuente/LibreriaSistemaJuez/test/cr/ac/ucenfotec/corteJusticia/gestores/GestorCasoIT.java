/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cr.ac.ucenfotec.corteJusticia.gestores;

import cr.ac.ucenfotec.corteJusticia.objetos.Caso;
import cr.ac.ucenfotec.corteJusticia.objetos.HistorialCaso;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ROLANDO
 */
public class GestorCasoIT {

    public GestorCasoIT() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of ingresarCaso method, of class GestorCaso.
     */
    @Test
    public void testIngresarCaso() throws Exception {
        System.out.println("ingresarCaso");
        String descripcion = "";
        GestorCaso instance = new GestorCaso();
//        instance.ingresarCaso(descripcion);
    }

    /**
     * Test of registrarCaso method, of class GestorCaso.
     */
    @Test
    public void testRegistrarCaso() throws Exception {
        System.out.println("registrarCaso");
        String cedula = "";
        String descripcion = "";
        GestorCaso instance = new GestorCaso();
//        instance.registrarCaso(cedula, descripcion);
    }

    /**
     * Test of listarCasosJuez method, of class GestorCaso.
     */
    @Test
    public void testListarCasosJuez() throws Exception {
        System.out.println("listarCasosJuez");
        GestorCaso instance = new GestorCaso();
        ArrayList<Caso> expResult = null;
        ArrayList<Caso> result = instance.listarCasosJuez();
        Assert.assertNotEquals(expResult, result);
    }

    /**
     * Test of listarCasosQuerellante method, of class GestorCaso.
     */
    @Test
    public void testListarCasosQuerellante() throws Exception {
        System.out.println("listarCasosQuerellante");
        GestorCaso instance = new GestorCaso();
        ArrayList<Caso> expResult = null;
        ArrayList<Caso> result = instance.listarCasosQuerellante();
        Assert.assertNotEquals(expResult, result);

    }

    /**
     * Test of comprobarRegistro method, of class GestorCaso.
     */
    @Test
    public void testComprobarRegistro() throws Exception {
        System.out.println("comprobarRegistro");
        int numero = 0;
        GestorCaso instance = new GestorCaso();
        boolean expResult = false;
        boolean result = instance.comprobarRegistro(numero);
        Assert.assertEquals(expResult, result);

    }

    /**
     * Test of buscarEstado method, of class GestorCaso.
     */
    @Test
    public void testBuscarEstado() throws Exception {
        System.out.println("buscarEstado");
        GestorCaso instance = new GestorCaso();
        String expResult = "";
        String result = instance.buscarEstado();
        Assert.assertNotEquals(expResult, result);

    }

    /**
     * Test of actulizarCaso method, of class GestorCaso.
     */
    @Test
    public void testActulizarCaso() throws Exception {
        System.out.println("actulizarCaso");
        String estado = "";
        String detalle = "";
        GestorCaso instance = new GestorCaso();
//        instance.actulizarCaso(estado, detalle);
    }

    /**
     * Test of listarHistorialCaso method, of class GestorCaso.
     */
    @Test
    public void testListarHistorialCaso() throws Exception {
        System.out.println("listarHistorialCaso");
        GestorCaso instance = new GestorCaso();
        ArrayList<HistorialCaso> expResult = null;
        ArrayList<HistorialCaso> result = instance.listarHistorialCaso();
        Assert.assertNotEquals(expResult, result);
    }

}
