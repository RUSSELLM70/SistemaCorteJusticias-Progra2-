/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cr.ac.ucenfotec.corteJusticia.gestores;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ROLANDO
 */
public class GestorQuerellanteIT {
    
    public GestorQuerellanteIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of agregarQuerellente method, of class GestorQuerellante.
     */
    @Test
    public void testAgregarQuerellente() throws Exception {
        System.out.println("agregarQuerellente");
        String cedula = "";
        String direccion = "";
        String nombre = "";
        String apellidos = "";
        String telefono = "";
        GestorQuerellante instance = new GestorQuerellante();
//        instance.agregarQuerellente(cedula, direccion, nombre, apellidos, telefono);

    }

    /**
     * Test of comprobarRegistroUsuario method, of class GestorQuerellante.
     */
    @Test
    public void testComprobarRegistroUsuario() throws Exception {
        System.out.println("comprobarRegistroUsuario");
        String cedula = "";
        GestorQuerellante instance = new GestorQuerellante();
        boolean expResult = false;
        boolean result = instance.comprobarRegistroUsuario(cedula);
        assertEquals(expResult, result);

    }

    /**
     * Test of verificarDatosLogin method, of class GestorQuerellante.
     */
    @Test
    public void testVerificarDatosLogin() throws Exception {
        System.out.println("verificarDatosLogin");
        String cedula = "";
        GestorQuerellante instance = new GestorQuerellante();
        boolean expResult = false;
        boolean result = instance.verificarDatosLogin(cedula);
        assertEquals(expResult, result);

    }
    
}
