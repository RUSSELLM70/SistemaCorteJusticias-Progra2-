/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cr.ac.ucenfotec.corteJusticia.gestores;

import cr.ac.ucenfotec.corteJusticia.objetos.Juez;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ROLANDO
 */
public class GestorJuezIT {

    public GestorJuezIT() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of agregarJuez method, of class GestorJuez.
     */
    @Test
    public void testAgregarJuez() throws Exception {
        System.out.println("agregarJuez");
        String cedula = "";
        String usuario = "";
        String clave = "";
        String nombre = "";
        String apellidos = "";
        String telefono = "";
        String sala = "";
        GestorJuez instance = new GestorJuez();
//        instance.agregarJuez(cedula, usuario, clave, nombre, apellidos, telefono, sala);
    }

    /**
     * Test of comprobarRegistroJuez method, of class GestorJuez.
     */
    @Test
    public void testComprobarRegistroJuez() throws Exception {
        System.out.println("comprobarRegistroJuez");
        String cedula = "";
        GestorJuez instance = new GestorJuez();
        boolean expResult = false;
        boolean result = instance.comprobarRegistroJuez(cedula);
        Assert.assertEquals(expResult, result);
    }

    /**
     * Test of comprobarRegistroUsuario method, of class GestorJuez.
     */
    @Test
    public void testComprobarRegistroUsuario() throws Exception {
        System.out.println("comprobarRegistroUsuario");
        String usuario = "";
        GestorJuez instance = new GestorJuez();
        boolean expResult = false;
        boolean result = instance.comprobarRegistroUsuario(usuario);
        assertEquals(expResult, result);

    }

    /**
     * Test of verificarDatosLogin method, of class GestorJuez.
     */
    @Test
    public void testVerificarDatosLogin() throws Exception {
        System.out.println("verificarDatosLogin");
        String usuario = "";
        String clave = "";
        GestorJuez instance = new GestorJuez();
        boolean expResult = false;
        boolean result = instance.verificarDatosLogin(usuario, clave);
        assertEquals(expResult, result);

    }

    /**
     * Test of buscar method, of class GestorJuez.
     */
    @Test
    public void testBuscar() throws Exception {
        System.out.println("buscar");
        GestorJuez instance = new GestorJuez();
        Juez expResult = null;
        Juez result = instance.buscar();
        assertEquals(expResult, result);
        
    }

}
