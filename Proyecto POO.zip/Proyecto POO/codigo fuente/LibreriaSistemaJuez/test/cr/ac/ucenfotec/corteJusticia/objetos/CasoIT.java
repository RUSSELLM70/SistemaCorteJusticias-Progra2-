/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cr.ac.ucenfotec.corteJusticia.objetos;

import java.time.LocalDate;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ROLANDO
 */
public class CasoIT {

    public CasoIT() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getNumero method, of class Caso.
     */
    @Test
    public void testGetNumero() {
        System.out.println("getNumero");
        Caso instance = new Caso();
        int expResult = 0;
        int result = instance.getNumero();
        assertEquals(expResult, result);

    }

    /**
     * Test of setNumero method, of class Caso.
     */
    @Test
    public void testSetNumero() {
        System.out.println("setNumero");
        int numero = 0;
        Caso instance = new Caso();
        instance.setNumero(numero);

    }

    /**
     * Test of getDescripcion method, of class Caso.
     */
    @Test
    public void testGetDescripcion() {
        System.out.println("getDescripcion");
        Caso instance = new Caso();
        String expResult = "";
        String result = instance.getDescripcion();
        assertEquals(expResult, result);

    }

    /**
     * Test of setDescripcion method, of class Caso.
     */
    @Test
    public void testSetDescripcion() {
        System.out.println("setDescripcion");
        String descripcion = "";
        Caso instance = new Caso();
        instance.setDescripcion(descripcion);

    }

    /**
     * Test of getMestado method, of class Caso.
     */
    @Test
    public void testGetMestado() {
        System.out.println("getMestado");
        Caso instance = new Caso();
        String expResult = "";
        String result = instance.getMestado();
        assertEquals(expResult, result);

    }

    /**
     * Test of setMestado method, of class Caso.
     */
    @Test
    public void testSetMestado() {
        System.out.println("setMestado");
        String mestado = "";
        Caso instance = new Caso();
        instance.setMestado(mestado);

    }

    /**
     * Test of getFecha method, of class Caso.
     */
    @Test
    public void testGetFecha() {
        System.out.println("getFecha");
        Caso instance = new Caso();
        LocalDate expResult = null;
        LocalDate result = instance.getFecha();
        assertEquals(expResult, result);

    }

    /**
     * Test of setFecha method, of class Caso.
     */
    @Test
    public void testSetFecha() {
        System.out.println("setFecha");
        LocalDate fecha = null;
        Caso instance = new Caso();
        instance.setFecha(fecha);

    }

    /**
     * Test of getMQuerellante method, of class Caso.
     */
    @Test
    public void testGetMQuerellante() {
        System.out.println("getMQuerellante");
        Caso instance = new Caso();
        String expResult = "";
        String result = instance.getMQuerellante();
        assertEquals(expResult, result);

    }

    /**
     * Test of setMQuerellante method, of class Caso.
     */
    @Test
    public void testSetMQuerellante() {
        System.out.println("setMQuerellante");
        String nombre = "";
        Caso instance = new Caso();
        instance.setMQuerellante(nombre);

    }

    /**
     * Test of getMJuez method, of class Caso.
     */
    @Test
    public void testGetMJuez() {
        System.out.println("getMJuez");
        Caso instance = new Caso();
        String expResult = "";
        String result = instance.getMJuez();
        assertEquals(expResult, result);

    }

    /**
     * Test of setMJuez method, of class Caso.
     */
    @Test
    public void testSetMJuez() {
        System.out.println("setMJuez");
        String nombre = "";
        Caso instance = new Caso();
        instance.setMJuez(nombre);

    }

    /**
     * Test of getDetalle method, of class Caso.
     */
    @Test
    public void testGetDetalle() {
        System.out.println("getDetalle");
        Caso instance = new Caso();
        String expResult = "";
        String result = instance.getDetalle();
        assertEquals(expResult, result);

    }

    /**
     * Test of setDetalle method, of class Caso.
     */
    @Test
    public void testSetDetalle() {
        System.out.println("setDetalle");
        String detalle = "";
        Caso instance = new Caso();
        instance.setDetalle(detalle);

    }

    /**
     * Test of toString method, of class Caso.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Caso instance = new Caso();
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);

    }

}
