/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cr.ac.ucenfotec.corteJusticia.objetos;

import java.time.LocalDateTime;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ROLANDO
 */
public class HistorialCasoIT {

    public HistorialCasoIT() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getNumeroCaso method, of class HistorialCaso.
     */
    @Test
    public void testGetNumeroCaso() {
        System.out.println("getNumeroCaso");
        HistorialCaso instance = new HistorialCaso();
        int expResult = 0;
        int result = instance.getNumeroCaso();
        assertEquals(expResult, result);

    }

    /**
     * Test of setNumeroCaso method, of class HistorialCaso.
     */
    @Test
    public void testSetNumeroCaso() {
        System.out.println("setNumeroCaso");
        int numeroCaso = 0;
        HistorialCaso instance = new HistorialCaso();
        instance.setNumeroCaso(numeroCaso);

    }

    /**
     * Test of getEstados method, of class HistorialCaso.
     */
    @Test
    public void testGetEstados() {
        System.out.println("getEstados");
        HistorialCaso instance = new HistorialCaso();
        String expResult = "";
        String result = instance.getEstados();
        assertEquals(expResult, result);

    }

    /**
     * Test of setEstados method, of class HistorialCaso.
     */
    @Test
    public void testSetEstados() {
        System.out.println("setEstados");
        String estado = "";
        HistorialCaso instance = new HistorialCaso();
        instance.setEstados(estado);

    }

    /**
     * Test of getFechas method, of class HistorialCaso.
     */
    @Test
    public void testGetFechas() {
        System.out.println("getFechas");
        HistorialCaso instance = new HistorialCaso();
        LocalDateTime expResult = null;
        LocalDateTime result = instance.getFechas();
        assertEquals(expResult, result);

    }

    /**
     * Test of setFechas method, of class HistorialCaso.
     */
    @Test
    public void testSetFechas() {
        System.out.println("setFechas");
        LocalDateTime fecha = null;
        HistorialCaso instance = new HistorialCaso();
        instance.setFechas(fecha);

    }

    /**
     * Test of toString method, of class HistorialCaso.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        HistorialCaso instance = new HistorialCaso();
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);

    }

}
