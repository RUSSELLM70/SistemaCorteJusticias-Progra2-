/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cr.ac.ucenfotec.corteJusticia.objetos;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ROLANDO
 */
public class SecretarioIT {

    public SecretarioIT() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getClave method, of class Secretario.
     */
    @Test
    public void testGetClave() {
        System.out.println("getClave");
        Secretario instance = new Secretario();
        String expResult = "";
        String result = instance.getClave();
        assertEquals(expResult, result);

    }

    /**
     * Test of setClave method, of class Secretario.
     */
    @Test
    public void testSetClave() {
        System.out.println("setClave");
        String clave = "";
        Secretario instance = new Secretario();
        instance.setClave(clave);

    }

    /**
     * Test of getUsuario method, of class Secretario.
     */
    @Test
    public void testGetUsuario() {
        System.out.println("getUsuario");
        Secretario instance = new Secretario();
        String expResult = "";
        String result = instance.getUsuario();
        assertEquals(expResult, result);

    }

    /**
     * Test of setUsuario method, of class Secretario.
     */
    @Test
    public void testSetUsuario() {
        System.out.println("setUsuario");
        String usuario = "";
        Secretario instance = new Secretario();
        instance.setUsuario(usuario);

    }

    /**
     * Test of toString method, of class Secretario.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Secretario instance = new Secretario();
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);

    }

}
