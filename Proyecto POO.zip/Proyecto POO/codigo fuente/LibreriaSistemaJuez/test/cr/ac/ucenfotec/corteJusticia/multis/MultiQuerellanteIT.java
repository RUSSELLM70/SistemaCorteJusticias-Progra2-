/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cr.ac.ucenfotec.corteJusticia.multis;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ROLANDO
 */
public class MultiQuerellanteIT {

    public MultiQuerellanteIT() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of guardar method, of class MultiQuerellante.
     */
    @Test
    public void testGuardar() throws Exception {
        System.out.println("guardar");
        String cedula = "";
        String direccion = "";
        String nombre = "";
        String apellidos = "";
        String telefono = "";
        MultiQuerellante instance = new MultiQuerellante();
        instance.guardar(cedula, direccion, nombre, apellidos, telefono);

    }

    /**
     * Test of comprobarRegistro method, of class MultiQuerellante.
     */
    @Test
    public void testComprobarRegistro() throws Exception {
        System.out.println("comprobarRegistro");
        String cedula = "";
        MultiQuerellante instance = new MultiQuerellante();
        boolean expResult = false;
        boolean result = instance.comprobarRegistro(cedula);
        assertEquals(expResult, result);

    }

    /**
     * Test of verificarDatosLogin method, of class MultiQuerellante.
     */
    @Test
    public void testVerificarDatosLogin() throws Exception {
        System.out.println("verificarDatosLogin");
        String cedula = "";
        MultiQuerellante instance = new MultiQuerellante();
        boolean expResult = false;
        boolean result = instance.verificarDatosLogin(cedula);
        assertEquals(expResult, result);

    }

}
