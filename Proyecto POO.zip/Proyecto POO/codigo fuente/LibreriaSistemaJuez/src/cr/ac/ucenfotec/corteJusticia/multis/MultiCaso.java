package cr.ac.ucenfotec.corteJusticia.multis;

import accesobd.Conector;
import cr.ac.ucenfotec.corteJusticia.objetos.Caso;
import cr.ac.ucenfotec.corteJusticia.objetos.HistorialCaso;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Random;

/**
 * MultiCaso se encarga de enviar consultas SQL a la base de datos (MYSQL), que
 * envian o reciben informacion relacionada con Caso.
 *
 * @author Rolando Conejo & Matthew Russell
 * @version 1.0
 */
public class MultiCaso {

    /**
     * Constructor vacio de la clase MultiCaso.
     */
    public MultiCaso() {
    }

    /**
     * Envia un setencia DML a la base de datos, para guardar un nuevo caso
     * ingresado por el querellante.
     *
     * @param descripcion
     * @throws Exception
     */
    public void guardar(String descripcion) throws Exception {
        String cedulaQuerellante, cedulaJuez;
        String query;

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();

        try {
            cedulaQuerellante = buscarUsuario();
            cedulaJuez = elegirJuez();

            query = "INSERT INTO casos(descripcion, estado, fecha, cedulaquerellante, cedulajuez, detalle)"
                    + "VALUES ('" + descripcion + "','" + "Recibido" + "','" + dtf.format(now) + "','" + cedulaQuerellante + "','" + cedulaJuez + "','" + "Caso Recibido" + "');";

            Conector.getConector().ejecutarSQL(query);
            darDatosHistorial();

        } catch (Exception e) {
            throw e;
        }

    }

    /**
     * Envia un setencia DML a la base de datos, para guardar un nuevo caso
     * registrado por el secretario.
     *
     * @param descripcion
     * @throws Exception
     */
    public void guardarSecretario(String descripcion, String cedulaQuerellante) throws Exception {
        String cedulaJuez;
        String query;

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();

        try {
            cedulaJuez = elegirJuez();
            query = "INSERT INTO casos(descripcion, estado, fecha, cedulaQuerellante, cedulajuez, detalle)"
                    + "VALUES ('" + descripcion + "','" + "Recibido" + "','" + dtf.format(now) + "','" + cedulaQuerellante + "','" + cedulaJuez + "','" + "Caso Recibido" + "');";

            Conector.getConector().ejecutarSQL(query);
            darDatosHistorial();

        } catch (Exception e) {
            throw e;
        }

    }

    /**
     * Envia una consulta SQL para buscar el usuario que esta en sesion en ese
     * momento.
     *
     * @return cedula
     * @throws Exception
     */
    private String buscarUsuario() throws Exception {
        ResultSet rs;
        String cedula = "";
        String query;
        query = "SELECT id "
                + "FROM usuarioycasoactual";

        try {
            rs = Conector.getConector().ejecutarSQL(query, true);

            if (rs.next()) {
                cedula = rs.getString("id");
            }

        } catch (Exception e) {
            throw e;
        }

        return cedula;

    }

    /**
     * Envia una consulta SQL a la base de datos, para traer la totalidad de
     * jueces registrados, y elegir entre todos uno que revice un caso.
     *
     * @return cedula
     * @throws java.sql.SQLException
     * @throws Exception
     */
    private String elegirJuez() throws java.sql.SQLException, Exception {
        Random randomGenerator = new Random();
        ArrayList<String> lista = new ArrayList<>();
        String query, cedula;
        ResultSet rs;
        query = "select cedula "
                + "from jueces";

        try {
            rs = Conector.getConector().ejecutarSQL(query, true);

            while (rs.next()) {
                lista.add(rs.getString("cedula"));
            }

            int index = randomGenerator.nextInt(lista.size());
            cedula = lista.get(index);

        } catch (Exception e) {
            throw e;

        }

        return cedula;

    }

    /**
     * Envia una consulta SQL a la base de datos, para buscar todos los casos
     * que un juez tenga que revisar.
     *
     * @return
     * @throws Exception
     */
    public ArrayList<Caso> listarCasosJuez() throws Exception {
        ArrayList<Caso> lista = new ArrayList<>();
        Caso tmpCaso;
        java.sql.ResultSet rs;
        String cedulaJuez;
        String query;

        try {
            cedulaJuez = buscarUsuario();
            query = "select c.numero, c.descripcion, CONCAT(q.nombre,' ', apellidos) as querellante, c.estado,c.detalle "
                    + "from casos c "
                    + "join querellantes q on(c.cedulaquerellante = q.cedula) "
                    + "where c.cedulajuez = '" + cedulaJuez + "' "
                    + "order by c.fecha;";
            rs = Conector.getConector().ejecutarSQL(query, true);

            while (rs.next()) {
                tmpCaso = new Caso(
                        rs.getInt("c.numero"),
                        rs.getString("c.descripcion"),
                        rs.getString("c.estado"),
                        rs.getString("querellante"),
                        rs.getString("Detalle"));

                lista.add(tmpCaso);
            }

            rs.close();

        } catch (Exception e) {
            throw e;
        }

        return lista;
    }

    /**
     * Envia una consulta SQL a la base de datos, para buscar todos los casos
     * que el querellante haya ingresado.
     *
     * @return lista
     * @throws Exception
     */
    public ArrayList<Caso> listarCasosQuerellante() throws Exception {
        ArrayList<Caso> lista = new ArrayList<>();
        Caso tmpCaso;
        java.sql.ResultSet rs;
        String cedulaQuerellante;
        String query;

        try {
            cedulaQuerellante = buscarUsuario();

            query = "select c.numero, c.descripcion, CONCAT(j.nombre,' ', j.apellidos) as juez, c.estado, c.detalle "
                    + "from casos c "
                    + "join jueces j on(c.cedulajuez = j.cedula) "
                    + "where c.cedulaquerellante = '" + cedulaQuerellante + "' "
                    + "order by c.fecha;";
            rs = Conector.getConector().ejecutarSQL(query, true);

            while (rs.next()) {
                tmpCaso = new Caso();
                tmpCaso.setDescripcion(rs.getString("c.descripcion"));
                tmpCaso.setNumero(rs.getInt("c.numero"));
                tmpCaso.setMJuez(rs.getString("juez"));
                tmpCaso.setDetalle(rs.getString("c.detalle"));
                tmpCaso.setMestado(rs.getString("c.estado"));
                
                lista.add(tmpCaso);
            }

            rs.close();

        } catch (Exception e) {
            throw e;
        }

        return lista;
    }

    /**
     * Envia una consulta SQL, para verificar si un caso se encuentra registrado
     * en la tabla casos por medio del numero de caso.
     *
     * @param numero
     * @return existe boolean que indica si el caso esta registrado
     * @throws Exception
     */
    public boolean comprobarRegistro(int numero) throws Exception {
        ResultSet rs = null;
        String query, cedula;
        boolean existe = false;

        try {
            cedula = buscarUsuario();
            query = "SELECT numero "
                    + "FROM casos "
                    + "WHERE numero = '" + numero + "'"
                    + "AND cedulajuez = '" + cedula + "';";

            rs = Conector.getConector().ejecutarSQL(query, true);

            if (rs.next()) {
                existe = true;
                actulizarCasoActual(rs.getInt("numero"));
            }

            rs.close();
//            Conector.getConector().cerrarConexion();

        } catch (Exception e) {
            throw e;
        }

        return existe;
    }

    /**
     * Envia una consulta SQL a la base de datos, con el fin de recibir el
     * numero y el estado del ultimo caso ingresado. Este metodo es llamado por
     * guardar y guardarSecretario, despues de ingresado un nuevo caso en la
     * base de datos. Al final envia los datos de la consulta a registrar
     * historial.
     *
     * @throws Exception
     */
    private void darDatosHistorial() throws Exception {
        ResultSet rs;
        String estado = "";
        int numero = 0;
        LocalDateTime fecha = LocalDateTime.now();
        String query;
        query = "SELECT numero, estado, fecha "
                + "FROM casos "
                + "ORDER BY numero DESC "
                + "LIMIT 1;";

        try {
            rs = Conector.getConector().ejecutarSQL(query, true);

            if (rs.next()) {
                numero = rs.getInt("numero");
                estado = rs.getString("estado");
                fecha = rs.getTimestamp("fecha").toLocalDateTime();
            }

            registrarHistorial(numero, estado, fecha);

        } catch (Exception e) {
            throw e;
        }

    }

    /**
     * Envia una sentencia DML (UPDATE) a la base de datos del estado y detalle,
     * para actulizar el caso elegido por el usuario juez.
     *
     * @param estado
     * @param detalle
     * @throws Exception
     */
    public void actulizarCaso(String estado, String detalle) throws Exception {
        String query;
        int numero;

        try {
            numero = buscarNumeroCaso();
            query = "UPDATE casos "
                    + "SET estado = '" + estado + "', detalle = '" + detalle + "' "
                    + "WHERE numero = '" + numero + "';";

            Conector.getConector().ejecutarSQL(query);
            registrarHistorial(estado);

        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * Envia una sentencia DML (INSERT) a la base de datos, para actulizar el
     * historial de un caso, despues de que este sea ingresado a la base de
     * datos.
     *
     * @param numero
     * @param estado
     * @param fecha
     * @throws java.lang.Exception
     */
    public void registrarHistorial(int numero, String estado, LocalDateTime fecha) throws Exception {
        String query;
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();

        query = "insert INTO historialcasos(numerocaso, fechacambio, estado) "
                + "values (" + numero + ",'" + fecha + "','" + estado + "');";

        try {
            Conector.getConector().ejecutarSQL(query);

        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * Envia una sentencia DML (INSERT) a la base de datos, para actulizar el
     * historial de un caso, despues de que este caso se haya actulizado en la
     * base de datos.
     *
     * @param estado
     * @throws Exception
     */
    public void registrarHistorial(String estado) throws Exception {
        String query;
        int numero;
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();

        try {
            numero = buscarNumeroCaso();
            query = "insert INTO historialcasos(numerocaso, fechacambio, estado) "
                    + "values (" + numero + ",'" + dtf.format(now) + "','" + estado + "');";

            Conector.getConector().ejecutarSQL(query);

        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * Envia una sentencia DML a la base de datos, para actulizar el caso que
     * haya elegido el juez, ya sea, para modificar el estado o ver historial.
     *
     * @param numero
     * @throws Exception
     */
    private void actulizarCasoActual(int numero) throws Exception {

        String query;

        query = "UPDATE usuarioycasoactual "
                + "SET numero = '" + numero + "';";
        try {
            Conector.getConector().ejecutarSQL(query);

        } catch (Exception e) {
            throw e;
        }

    }

    /**
     * Envia una consulta SQL a la base de datos, para buscar el estado actual
     * del caso, que haya elegido el usuario juez.
     *
     * @return estado
     * @throws Exception
     */
    public String buscarEstado() throws Exception {
        ResultSet rs = null;
        String query, estado = "";

        query = "SELECT estado "
                + "FROM casos "
                + "WHERE numero = (select numero "
                + "from usuarioycasoactual);";

        try {
            rs = Conector.getConector().ejecutarSQL(query, true);

            if (rs.next()) {
                estado = rs.getString("estado");

            }

            rs.close();
//            Conector.getConector().cerrarConexion();

        } catch (Exception e) {
            throw e;
        }

        return estado;
    }

    /**
     * Envia una consulta SQL a la base de datos, para buscar el numero del
     * caso, que haya elegido el usuario juez.
     *
     * @return estado
     * @throws Exception
     */
    public int buscarNumeroCaso() throws Exception {
        ResultSet rs = null;
        String query;
        int numero = 0;

        query = "select numero "
                + "from usuarioycasoactual;";

        try {
            rs = Conector.getConector().ejecutarSQL(query, true);

            if (rs.next()) {
                numero = rs.getInt("numero");
            }

            rs.close();
//            Conector.getConector().cerrarConexion();

        } catch (Exception e) {
            throw e;
        }

        return numero;
    }

    /**
     * Envia un consulta SQL a la base de datos, para seleccionar el historial
     * de un caso.
     *
     * @return
     * @throws Exception
     */
    public ArrayList<HistorialCaso> listarHistorialCaso() throws Exception {
        ArrayList<HistorialCaso> lista = new ArrayList<>();
        String estado = "";
        LocalDateTime fecha = LocalDateTime.now();
        HistorialCaso tmpHistorialCaso;
        int numero;
        java.sql.ResultSet rs;
        String query;

        try {
            numero = buscarNumeroCaso();

            query = "Select numerocaso, fechacambio, estado "
                    + "from historialcasos "
                    + "where numerocaso = " + numero + " "
                    + "order by fechacambio;";
            rs = Conector.getConector().ejecutarSQL(query, true);

            while (rs.next()) {
                tmpHistorialCaso = new HistorialCaso(
                        numero = rs.getInt("numerocaso"),
                        estado = rs.getString("estado"),
                        fecha = rs.getTimestamp("fechacambio").toLocalDateTime());

                lista.add(tmpHistorialCaso);

            }

            rs.close();

        } catch (Exception e) {
            throw e;
        }

        return lista;
    }

}
