package cr.ac.ucenfotec.corteJusticia.gestores;

import cr.ac.ucenfotec.corteJusticia.multis.MultiQuerellante;
import java.sql.SQLException;

/**
 * Envia y recibe datos provenientes de la interfaz grafica de usuario, y los
 * envia o recibe de la clase MultiQuerellante, que es la encargada de
 * interactuar con la base de datos que contiene la tabla querellantes.
 *
 * @author Rolando Conejo & Matthew Russell
 * @version 1.0
 */
public class GestorQuerellante {

    public static String cedulaQuerellante;

    /**
     * Constructor vacio.
     */
    public GestorQuerellante() {
    }

    /**
     * Envia la informacion de un querellante para su registro.
     *
     * @param cedula
     * @param direccion
     * @param nombre
     * @param apellidos
     * @param telefono
     * @throws java.sql.SQLException
     * @throws Exception
     */
    public void agregarQuerellente(String cedula, String direccion, String nombre, String apellidos, String telefono) throws java.sql.SQLException, Exception {
        try {
            new MultiQuerellante().guardar(cedula, direccion, nombre, apellidos, telefono);

        } catch (java.lang.ClassNotFoundException | SQLException e) {
            throw e;
        }

    }

    /**
     * Envia la cedula de un querellante para verificar si se encuentra
     * registrado.
     *
     * @param cedula
     * @return existe
     * @throws Exception
     */
    public boolean comprobarRegistroUsuario(String cedula) throws Exception {
        boolean existe;
        try {
            existe = new MultiQuerellante().comprobarRegistro(cedula);
        } catch (java.lang.ClassNotFoundException | SQLException e) {
            throw e;
        }
        return existe;
    }

    /**
     * Envia la cedula del querellante que quiera iniciar sesion para verificar
     * si se encuentra registrada.
     *
     * @param cedula
     * @return existe
     * @throws Exception
     */
    public boolean verificarDatosLogin(String cedula) throws Exception {
        boolean existe;
        try {
            existe = new MultiQuerellante().verificarDatosLogin(cedula);
            if (existe) {
                this.cedulaQuerellante = cedula;
            }
        } catch (java.lang.ClassNotFoundException | SQLException e) {
            throw e;
        }
        return existe;
    }

}
