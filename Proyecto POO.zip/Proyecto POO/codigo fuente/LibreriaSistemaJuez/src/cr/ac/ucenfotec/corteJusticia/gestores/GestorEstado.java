package cr.ac.ucenfotec.corteJusticia.gestores;

import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Clase que contiene la logica de los cambios de estado de un caso.
 *
 * @author Rolando Conejo & Matthew Russell
 * @version 1.0
 */
public class GestorEstado {

    public GestorEstado() {
    }

    /**
     * Este metodo retorna una lista con los estado a la interfaz Grafica.
     * 
     * @return lista lista que contiene los estados
     * @throws ClassNotFoundException
     * @throws SQLException
     * @throws Exception 
     */
    public ArrayList<String> listarEstados() throws ClassNotFoundException, SQLException, Exception {
        GestorCaso logica = new GestorCaso();
        ArrayList<String> lista = new ArrayList<>();
        String estado;

        try {
            estado = logica.buscarEstado();

            if (estado.equals("Recibido")) {
                lista.add("Aceptado");
                lista.add("Consulta");
                lista.add("Rechazado");

            } else if (estado.equals("Consulta")) {
                lista.add("Aceptado");
                lista.add("Rechazado");

            } else if (estado.equals("Aceptado")) {
                lista.add("Redactado1");

            } else if (estado.equals("Redactado1")) {
                lista.add("Revision");

            } else if (estado.equals("Revision")) {
                lista.add("Redactado2");
                
            } else if (estado.equals("Redactado2")) {
                lista.add("Resulto");
                
            } else if (estado.equals("Resuelto") || estado.equals("Rechazado")) {

            }
        } catch (java.lang.ClassNotFoundException | SQLException e) {
            throw e;
        }

        return lista;
    }

}
