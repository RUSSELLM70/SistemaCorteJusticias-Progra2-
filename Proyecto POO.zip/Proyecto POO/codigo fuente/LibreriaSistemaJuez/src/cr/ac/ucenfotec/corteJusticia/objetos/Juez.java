package cr.ac.ucenfotec.corteJusticia.objetos;

/**
 * Esta clase contiene los metodos y atributos cada Juez.
 *
 * @author Rolando Conejo & Matthew Russell
 * @version 1.0
 */
public class Juez extends Persona {

    private String cedula;
    private String usuario;
    private String clave;
    private String sala;

    /*
     *contructor por defecto
     */
    public Juez() {
        super();
    }

    /**
     * Constructor que recibe los parametros.
     *
     * @param cedula
     * @param usuario
     * @param clave
     * @param sala
     * @param nombre
     * @param apellidos
     * @param telefono
     */
    public Juez(String cedula, String usuario, String clave, String sala, String nombre, String apellidos, String telefono) {
        super(nombre, apellidos, telefono);
        this.cedula = cedula;
        this.usuario = usuario;
        this.clave = clave;
        this.sala = sala;
    }

    /**
     * Retorna la cedula del juez.
     *
     * @return cedula
     */
    public String getCedula() {
        return cedula;
    }

    /**
     * Recibe la cedula del juez.
     *
     * @param cedula
     */
    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    /**
     * Retorna el nombre de usuario del juez.
     *
     * @return usuario
     */
    public String getUsuario() {
        return usuario;
    }

    /**
     * Recibe el nombre de usuario del juez.
     *
     * @param usuario
     */
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    /**
     * Retorna la clave del juez.
     *
     * @return clave
     */
    public String getClave() {
        return clave;
    }

    /**
     * Recibe la clave del juez.
     *
     * @param clave
     */
    public void setClave(String clave) {
        this.clave = clave;
    }

    /**
     * Retorna la sala del juez.
     *
     * @return sala
     */
    public String getSala() {
        return sala;
    }

    /**
     * Recibe la sala del juez.
     *
     * @param sala
     */
    public void setSala(String sala) {
        this.sala = sala;
    }

    @Override
    public String toString() {
        return "Juez{" + "nombre=" + nombre + ", apellidos=" + apellidos
                + ", telefono=" + telefono + ", cedula=" + cedula + ", usuario="
                + usuario + ", clave=" + clave + ", sala=" + sala + '}';
    }

}
