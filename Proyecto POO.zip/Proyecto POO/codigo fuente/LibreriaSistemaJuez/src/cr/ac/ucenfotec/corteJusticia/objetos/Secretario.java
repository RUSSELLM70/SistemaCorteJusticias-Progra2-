package cr.ac.ucenfotec.corteJusticia.objetos;

/**
 * Esta clase contiene los metodos y atributos cada Secretario.
 *
 * @author Rolando Conejo & Matthew Russell
 * @version 1.0
 */
public class Secretario extends Persona {

    String clave;
    String usuario;

    /**
     * Constructor vacio.
     */
    public Secretario() {
    }

    /**
     * Constructor que recibe los parametros.
     *
     * @param clave
     * @param usuario
     * @param nombre
     * @param apellidos
     * @param telefono
     */
    public Secretario(String clave, String usuario, String nombre, String apellidos, String telefono) {
        super(nombre, apellidos, telefono);
        this.clave = clave;
        this.usuario = usuario;
    }

    /**
     * Retorna la clave del secretario
     *
     * @return clave.
     */
    public String getClave() {
        return clave;
    }

    /**
     * Recibe la clave del secretario/
     *
     * @param clave
     */
    public void setClave(String clave) {
        this.clave = clave;
    }

    /**
     * Retorna el usuario del secretario.
     *
     * @return usuario
     */
    public String getUsuario() {
        return usuario;
    }

    /**
     * Recibe el usuario del secretario.
     *
     * @param usuario
     */
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    @Override
    public String toString() {
        return "Secretario{" + "clave=" + clave + ", Usuario=" + usuario + '}';
    }

}
