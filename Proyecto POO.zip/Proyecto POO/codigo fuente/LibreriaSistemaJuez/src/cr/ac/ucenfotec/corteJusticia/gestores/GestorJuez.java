package cr.ac.ucenfotec.corteJusticia.gestores;

import cr.ac.ucenfotec.corteJusticia.objetos.Juez;
import cr.ac.ucenfotec.corteJusticia.multis.MultiJuez;
import java.sql.SQLException;

/**
 * Envia y recibe datos provenientes de la interfaz grafica de usuario, y los
 * envia o recibe de la clase MultiJuez, que es la encargada de interactuar con
 * la base de datos que contiene la tabla jueces.
 *
 * @author Rolando Conejo & Matthew Russell
 * @version 1.0
 */
public class GestorJuez {

    public static String cedulaJuez;

    /**
     * Constructor vacio.
     */
    public GestorJuez() {
    }

    /**
     * Envia la informacion de un juez para su registro.
     *
     * @param cedula
     * @param usuario
     * @param clave
     * @param nombre
     * @param apellidos
     * @param telefono
     * @param sala
     * @throws java.sql.SQLException
     * @throws Exception
     */
    public void agregarJuez(String cedula, String usuario, String clave, String nombre, String apellidos, String telefono, String sala) throws java.sql.SQLException, Exception {
        try {
            new MultiJuez().guardar(cedula, usuario, clave, nombre, apellidos, telefono, sala);

        } catch (java.lang.ClassNotFoundException | SQLException e) {
            throw e;
        }

    }

    /**
     * Envia la cedula para verificar si un juez se encuentra registrado.
     *
     * @param cedula
     * @return existe
     * @throws Exception
     */
    public boolean comprobarRegistroJuez(String cedula) throws Exception {
        boolean existe;
        try {
            existe = new MultiJuez().comprobarRegistro(cedula);
        } catch (java.lang.ClassNotFoundException | SQLException e) {
            throw e;
        }
        return existe;
    }

    /**
     * Envia el nombre de usuario de un juez para verificar si ya se encuentra
     * registrado.
     *
     * @param usuario
     * @return existe
     * @throws Exception
     */
    public boolean comprobarRegistroUsuario(String usuario) throws Exception {
        boolean existe;
        try {
            existe = new MultiJuez().comprobarUsuario(usuario);
        } catch (java.lang.ClassNotFoundException | SQLException e) {
            throw e;
        }
        return existe;
    }

    /**
     * Envia el usuario y la clave para verificar si conduerda con los datos del
     * juez que esta tratando de iniciar sesion.
     *
     * @param usuario
     * @param clave
     * @return existe
     * @throws Exception
     */
    public boolean verificarDatosLogin(String usuario, String clave) throws Exception {
        boolean existe;
        try {
            existe = new MultiJuez().verificarDatosLogin(usuario, clave);

        } catch (java.lang.ClassNotFoundException | SQLException e) {
            throw e;
        }
        return existe;
    }

    /**
     * Envia a la interfaz grafica la informacion del juez en sesion.
     *
     * @return tmpJuez
     * @throws java.sql.SQLException
     * @throws Exception
     */
    public Juez buscar() throws java.sql.SQLException, Exception {
        Juez tmpJuez;

        try {
            tmpJuez = new MultiJuez().buscar();
        } catch (java.lang.ClassNotFoundException | SQLException e) {
            throw e;
        }

        return tmpJuez;
    }

}
