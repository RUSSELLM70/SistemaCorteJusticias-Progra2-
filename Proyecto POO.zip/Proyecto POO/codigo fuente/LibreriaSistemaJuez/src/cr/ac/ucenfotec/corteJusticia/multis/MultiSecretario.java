package cr.ac.ucenfotec.corteJusticia.multis;

import accesobd.Conector;
import java.sql.ResultSet;

/**
 * MultiSecretario se encarga de enviar consultas SQL a la base de datos
 * (MYSQL), que envian o reciben informacion relacionada con los secretarios.
 *
 * @author Rolando Conejo & Matthew Russell
 * @version 1.0
 */
public class MultiSecretario {

    /**
     * Constructor vacio.
     */
    public MultiSecretario() {
    }

    /**
     * Envia una sentencia DML(INSERT) a la base de datos, para guardar la
     * informacion de un secretario.
     *
     * @param clave
     * @param usuario
     * @param nombre
     * @param apellidos
     * @param telefono
     * @throws Exception
     */
    public void guardar(String clave, String usuario, String nombre, String apellidos, String telefono) throws Exception {
        String query;
        query = "INSERT INTO secretarios (clave, usuario, nombre, apellidos, telefono)"
                + "VALUES ('" + clave + "','" + usuario + "','" + nombre + "','" + apellidos + "','" + telefono + "');";

        try {
            Conector.getConector().ejecutarSQL(query);

        } catch (Exception e) {
            throw e;
        }

    }

    /**
     * Envia una consulta SQL a la base de datos, para verificar si en la tabla
     * secretarios, se encuentra un secretario que se identifique con el usuario
     * enviado como parametro.
     *
     * @param usuario
     * @return
     * @throws Exception
     */
    public boolean comprobarRegistro(String usuario) throws Exception {
        ResultSet rs = null;
        String query;
        boolean existe = false;

        query = "SELECT usuario "
                + "FROM secretarios "
                + "WHERE usuario = '" + usuario + "';";

        try {
            rs = Conector.getConector().ejecutarSQL(query, true);

            if (rs.next()) {
                existe = true;
            }

            rs.close();
//            Conector.getConector().cerrarConexion();

        } catch (Exception e) {
            throw e;
        }

        return existe;
    }

    /**
     * Envia una consulta SQL a la base de datos, para verificar si en la tabla
     * secretarios se encuentra un secretario que se identifique con el usuario
     * y la clave enviadas como parametro.
     *
     * @param usuario
     * @param clave
     * @return
     * @throws Exception
     */
    public boolean verificarDatosLogin(String usuario, String clave) throws Exception {
        ResultSet rs = null;
        String query;
        boolean existe = false;

        query = "SELECT usuario "
                + "FROM secretarios "
                + "WHERE usuario = '" + usuario + "' AND clave = '" + clave + "';";

        try {
            rs = Conector.getConector().ejecutarSQL(query, true);

            if (rs.next()) {
//                this.usuarioSecretario = usuario;
                existe = true;
            }

            rs.close();
//            Conector.getConector().cerrarConexion();

        } catch (Exception e) {
            throw e;
        }

        return existe;
    }

}
