package cr.ac.ucenfotec.corteJusticia.gestores;

import cr.ac.ucenfotec.corteJusticia.multis.MultiSecretario;
import java.sql.SQLException;

/**
 * Envia y recibe datos provenientes de la interfaz grafica de usuario, y los
 * envia o recibe de la clase MultiSecretario, que es la encargada de
 * interactuar con la base de datos que contiene la tabla secretarios.
 *
 * @author Rolando Conejo & Matthew Russell
 * @version 1.0
 */
public class GestorSecretario {

    public static String usuarioSecretario;

    /**
     * Constructor vacio.
     */
    public GestorSecretario() {
    }

    /**
     * Envia la informacion del secretario para su registro en la base de datos.
     *
     * @param clave
     * @param usuario
     * @param nombre
     * @param apellidos
     * @param telefono
     * @throws java.sql.SQLException
     * @throws Exception
     */
    public void agregarSecretario(String clave, String usuario, String nombre, String apellidos, String telefono) throws java.sql.SQLException, Exception {
        try {
            new MultiSecretario().guardar(clave, usuario, nombre, apellidos, telefono);

        } catch (java.lang.ClassNotFoundException | SQLException e) {
            throw e;
        }

    }

    /**
     * Envia el usuario del secretario a verificar si se encuentra registrado.
     *
     * @param usuario
     * @return existe
     * @throws Exception
     */
    public boolean comprobarRegistroUsuario(String usuario) throws Exception {
        boolean existe;
        try {
            existe = new MultiSecretario().comprobarRegistro(usuario);
        } catch (java.lang.ClassNotFoundException | SQLException e) {
            throw e;
        }
        return existe;
    }

    /**
     * Envia a verificar si la clave y el usuario se encuentran registrados.
     *
     * @param usuario
     * @param clave
     * @return existe
     * @throws Exception
     */
    public boolean verificarDatosLogin(String usuario, String clave) throws Exception {
        boolean existe;
        try {
            existe = new MultiSecretario().verificarDatosLogin(usuario, clave);
            if (existe) {
                this.usuarioSecretario = usuario;
            }

        } catch (java.lang.ClassNotFoundException | SQLException e) {
            throw e;
        }
        return existe;
    }
}
