package cr.ac.ucenfotec.corteJusticia.multis;

import accesobd.Conector;
import java.sql.ResultSet;

/**
 * MultiQuerellante se encarga de enviar consultas SQL a la base de datos
 * (MYSQL), que envian o reciben informacion relacionada con los querellante.
 *
 * @author Rolando Conejo & Matthew Russell
 * @version 1.0
 */
public class MultiQuerellante {

    /**
     * Constructor vacio.
     */
    public MultiQuerellante() {
    }

    /**
     * Envia una sentencia DML(INSERT) a la base de datos, para guardar la
     * informacion de un querellante.
     *
     * @param cedula
     * @param direccion
     * @param nombre
     * @param apellidos
     * @param telefono
     * @throws Exception
     */
    public void guardar(String cedula, String direccion, String nombre, String apellidos, String telefono) throws Exception {
        String query;
        query = "INSERT INTO querellantes (cedula, direccion, nombre, apellidos, telefono)"
                + "VALUES ('" + cedula + "','" + direccion + "','" + nombre + "','" + apellidos + "','" + telefono + "');";

        try {
            Conector.getConector().ejecutarSQL(query);

        } catch (Exception e) {
            throw e;
        }

    }

    /**
     * Envia una consulta SQL a la base de datos, para verificar si en la tabla
     * querellantes, se encuentra un querellante que se identifique con la
     * cedula enviada como parametro.
     *
     * @param cedula
     * @return
     * @throws Exception
     */
    public boolean comprobarRegistro(String cedula) throws Exception {
        ResultSet rs = null;
        String query;
        boolean existe = false;

        query = "SELECT cedula "
                + "FROM querellantes "
                + "WHERE cedula = '" + cedula + "';";

        try {
            rs = Conector.getConector().ejecutarSQL(query, true);

            if (rs.next()) {
                existe = true;
            }

//            rs.close();
        } catch (Exception e) {
            throw e;
        }

        return existe;
    }

    /**
     * Envia una consulta SQL a la base de datos, para verificar si en la tabla
     * querellantes, se encuentra un querellante que se identifique con la
     * cedula enviada como parametro y permitirle iniciar sesion si se
     * encuentra.
     *
     * @param cedula
     * @return
     * @throws Exception
     */
    public boolean verificarDatosLogin(String cedula) throws Exception {
        ResultSet rs = null;
        String query;
        boolean existe = false;

        query = "SELECT cedula "
                + "FROM querellantes "
                + "WHERE cedula = '" + cedula + "';";

        try {
            rs = Conector.getConector().ejecutarSQL(query, true);

            if (rs.next()) {
//                this.cedulaQuerellante = rs.getString("cedula");
                actulizarUsuario(rs.getString("cedula"));
                existe = true;
            }

//            rs.close();
        } catch (Exception e) {
            throw e;
        }

        return existe;
    }

    /**
     * Envia una consulta SQL a la base de datos, para actualizar el usuario que
     * esta en sesion en el momento de usar la aplicacion.
     *
     * @param cedula
     * @throws Exception
     */
    private void actulizarUsuario(String cedula) throws Exception {

        String query;

        query = "UPDATE usuarioycasoactual "
                + "SET id = '" + cedula + "';";
        try {
            Conector.getConector().ejecutarSQL(query);

        } catch (Exception e) {
            throw e;
        }

    }

}
