package cr.ac.ucenfotec.corteJusticia.objetos;

/**
 * Esta clase contiene los metodos y atributos cada Persona.
 *
 * @author Rolando Conejo & Matthew Russell
 * @version 1.0
 */
public class Persona {

    /*
 *nombre de el juez o querellante    
     */
    protected String nombre;
    /*
 *apellido de el juez o querellante
     */
    protected String apellidos;
    /*
 *telefono de el juez o querellante 
     */
    protected String telefono;

    /*
 *constructor por defecto
     */
    public Persona() {

    }

    /**
     * Contructor con 4 parametros
     *
     * @param nombre nombre de el juez o querellante
     * @param apellidos apellido de el juez o querellante
     * @param telefono telefono de el juez o querellante
     */
    public Persona(String nombre, String apellidos, String telefono) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.telefono = telefono;
    }

    /**
     * metodo getNombre no recibe parametros
     *
     * @return retorna un String nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * metodo getApellido no recibe parametros
     *
     * @return retorna un String apellido
     */
    public String getApellidos() {
        return apellidos;
    }

    /**
     * metodo getTelefono no recibe parametros
     *
     * @return retorna un String telefono
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * metodo setNombre
     *
     * @param nombre nombre de el juez o querellante
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * metodo setApellido
     *
     * @param apellidos apellido de el juez o querellante
     */
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    /**
     * metodo setTelefono
     *
     * @param telefono telefono de el juez o querellante
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        return "Persona{" + "nombre=" + nombre + ", apellidos=" + apellidos + ", telefono=" + telefono + '}';
    }

}
