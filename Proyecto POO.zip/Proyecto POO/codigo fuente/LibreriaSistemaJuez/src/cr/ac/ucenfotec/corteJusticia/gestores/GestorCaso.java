package cr.ac.ucenfotec.corteJusticia.gestores;

import cr.ac.ucenfotec.corteJusticia.multis.MultiCaso;
import java.util.ArrayList;
import cr.ac.ucenfotec.corteJusticia.objetos.Caso;
import cr.ac.ucenfotec.corteJusticia.objetos.HistorialCaso;
import java.sql.SQLException;

/**
 * Envia y recibe datos provenientes de la interfaz grafica de usuario, y los
 * envia o recibe de la clase MultiCaso, que es la encargada de interactuar
 * con la base de datos que contiene la tabla casos.
 *
 * @author Rolando Conejo & Matthew Russell
 * @version 1.0
 */
public class GestorCaso {

    /**
     * Constructor vacio.
     */
    public GestorCaso() {
    }

    /**
     * Envia la descripcion de un caso, para su registro.
     *
     * @param descripcion
     * @throws java.sql.SQLException
     * @throws Exception
     */
    public void ingresarCaso(String descripcion) throws java.sql.SQLException, Exception {
        try {
            new MultiCaso().guardar(descripcion);

        } catch (java.lang.ClassNotFoundException | SQLException e) {
            throw e;
        }

    }

    /**
     * Envia la cedula y la descripcion de un caso introducido por un
     * secretario, para su registro.
     *
     * @param cedula
     * @param descripcion
     * @throws java.sql.SQLException
     * @throws Exception
     */
    public void registrarCaso(String cedula, String descripcion) throws java.sql.SQLException, Exception {
        try {
            new MultiCaso().guardarSecretario(descripcion, cedula);

        } catch (java.lang.ClassNotFoundException | SQLException e) {
            throw e;
        }

    }

    /**
     * Envia a la interfaz grafica la lista con los casos del juez en sesion.
     *
     * @return listaCasos
     * @throws java.sql.SQLException
     * @throws Exception
     */
    public ArrayList<Caso> listarCasosJuez() throws java.sql.SQLException, Exception {
        ArrayList<Caso> listaCasos = new ArrayList<>();

        try {
            listaCasos = new MultiCaso().listarCasosJuez();
        } catch (java.lang.ClassNotFoundException | SQLException e) {
            throw e;
        }

        return listaCasos;
    }

    /**
     * Envia a la interfaz grafica de usuario, la informacion de los casos del
     * usuario querellante en sesion.
     *
     * @return listaCasos
     * @throws java.sql.SQLException
     * @throws Exception
     */
    public ArrayList<Caso> listarCasosQuerellante() throws java.sql.SQLException, Exception {
        ArrayList<Caso> listaCasos = new ArrayList<>();

        try {
            listaCasos = new MultiCaso().listarCasosQuerellante();
        } catch (java.lang.ClassNotFoundException | SQLException e) {
            throw e;
        }

        return listaCasos;
    }

    /**
     * Envia el numero del caso para verificar si se encuntra registrado.
     *
     * @param numero
     * @return numero
     * @throws Exception
     */
    public boolean comprobarRegistro(int numero) throws Exception {
        boolean existe;
        try {
            existe = new MultiCaso().comprobarRegistro(numero);
        } catch (java.lang.ClassNotFoundException | SQLException e) {
            throw e;
        }
        return existe;
    }

    /**
     * Envia a la interfaz grafica el estado de un caso.
     *
     * @return estado
     * @throws Exception
     */
    public String buscarEstado() throws Exception {
        String estado;
        try {
            estado = new MultiCaso().buscarEstado();
        } catch (java.lang.ClassNotFoundException | SQLException e) {
            throw e;
        }
        return estado;
    }

    /**
     * Envia el estado y detalle para actulizar el estado.
     *
     * @param estado
     * @param detalle
     * @throws java.sql.SQLException
     * @throws Exception
     */
    public void actulizarCaso(String estado, String detalle) throws java.sql.SQLException, Exception {
        try {
            new MultiCaso().actulizarCaso(estado, detalle);

        } catch (java.lang.ClassNotFoundException | SQLException e) {
            throw e;
        }

    }

    /**
     * Envia a la interfaz grafica de usuario, la informacion del historial de
     * un caso.
     *
     * @return listaCasos
     * @throws java.sql.SQLException
     * @throws Exception
     */
    public ArrayList<HistorialCaso> listarHistorialCaso() throws java.sql.SQLException, Exception {
        ArrayList<HistorialCaso> lista;

        try {
            lista = new MultiCaso().listarHistorialCaso();
        } catch (java.lang.ClassNotFoundException | SQLException e) {
            throw e;
        }

        return lista;
    }

}
