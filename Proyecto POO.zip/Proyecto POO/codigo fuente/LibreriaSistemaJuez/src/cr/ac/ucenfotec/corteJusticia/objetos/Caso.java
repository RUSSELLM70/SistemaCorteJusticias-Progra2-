package cr.ac.ucenfotec.corteJusticia.objetos;

import java.time.LocalDate;

/**
 * Esta clase contiene los metodos y atributos de cada Caso.
 *
 * @author Rolando Conejo & Matthew Russell
 * @version 1.0
 */
public class Caso {

    private int numero;
    private String descripcion;
    private String mestado;
    private LocalDate fecha;
    private Querellante mQuerellante;
    private Juez mJuez;
    private String detalle;

    /**
     * Constructor vacio.
     */
    public Caso() {
    }

    /**
     * Constructor que recibe los parametros, inicializa el querellante.
     *
     * @param numero
     * @param descripcion
     * @param mestado
     * @param nombreQuerellante
     * @param detalle
     */
    public Caso(int numero, String descripcion, String mestado, String nombreQuerellante, String detalle) {
        this.numero = numero;
        this.descripcion = descripcion;
        this.mestado = mestado;
        this.mQuerellante = new Querellante();
        this.mQuerellante.setNombre(nombreQuerellante);
        this.detalle = detalle;
    }

    /**
     * Retorna el numero del caso.
     *
     * @return numero
     */
    public int getNumero() {
        return numero;
    }

    /**
     * Recibe el numero del caso.
     *
     * @param numero
     */
    public void setNumero(int numero) {
        this.numero = numero;
    }

    /**
     * Retorna la descripcion del caso.
     *
     * @return descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * Recibe la descripcion del caso.
     *
     * @param descripcion
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * Retorna el estado del caso.
     *
     * @return mestado
     */
    public String getMestado() {
        return mestado;
    }

    /**
     * Recibe el estado del caso.
     *
     * @param mestado
     */
    public void setMestado(String mestado) {
        this.mestado = mestado;
    }

    /**
     * Retorna la fecha del caso.
     *
     * @return fecha
     */
    public LocalDate getFecha() {
        return fecha;
    }

    /**
     * Recibe la fecha del caso.
     *
     * @param fecha
     */
    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    /**
     * Retorna el nombre del querellante.
     *
     * @return mQuerellante
     */
    public String getMQuerellante() {
        return mQuerellante.getNombre();
    }

    /**
     * Recibe el nombre del querellante.
     *
     * @param nombre
     */
    public void setMQuerellante(String nombre) {
        this.mQuerellante = new Querellante();
        this.mQuerellante.setNombre(nombre);
    }

    /**
     * Retorna el nombre del juez.
     *
     * @return mJuez
     */
    public String getMJuez() {
        return mJuez.getNombre();
    }

    /**
     * Recibe el nombre del juez.
     *
     * @param nombre
     */
    public void setMJuez(String nombre) {
        this.mJuez = new Juez();
        this.mJuez.setNombre(nombre);
    }

    /**
     * Retorna el detalle del caso.
     *
     * @return detalle
     */
    public String getDetalle() {
        return detalle;
    }

    /**
     * Recibe el detalle del caso.
     *
     * @param detalle
     */
    public void setDetalle(String detalle) {
        this.detalle = detalle;
    }

    @Override
    public String toString() {
        return "Caso{" + "numero=" + numero + ", descripcion=" + descripcion + ", mestado=" + mestado + ", fecha=" + fecha + ", Querellante=" + mQuerellante.getNombre() + ", Juez=" + mJuez.getNombre() + ", detalle=" + detalle + '}';
    }

}
