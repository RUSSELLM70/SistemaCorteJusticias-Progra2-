package cr.ac.ucenfotec.corteJusticia.objetos;

/**
 * Esta clase contiene los metodos y atributos cada Querellante.
 *
 * @author Rolando Conejo & Matthew Russell
 * @version 1.0
 */
public class Querellante extends Persona {

    private String cedula;
    private String direccion;

    /**
     * Constructor vacio.
     */
    public Querellante() {
    }

    /**
     * Constructor que recibe los parametros.
     *
     * @param cedula
     * @param direccion
     * @param nombre
     * @param apellidos
     * @param telefono
     */
    public Querellante(String cedula, String direccion, String nombre, String apellidos, String telefono) {
        super(nombre, apellidos, telefono);
        this.cedula = cedula;
        this.direccion = direccion;
    }

    /**
     * Retorna la cedula del querellante.
     *
     * @return cedula
     */
    public String getCedula() {
        return cedula;
    }

    /**
     * Recibe la cedula del querellante.
     *
     * @param cedula
     */
    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    /**
     * Retorna la direccion del querellante.
     *
     * @return direccion
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * Recibe la direccion del querellante.
     *
     * @param direccion
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    @Override
    public String toString() {
        return "Querellante{" + "nombre=" + nombre + ", apellidos=" + apellidos + ", telefono=" + telefono + "cedula=" + cedula + ", direccion=" + direccion + '}';
    }

}
