package cr.ac.ucenfotec.corteJusticia.multis;

import accesobd.Conector;
import cr.ac.ucenfotec.corteJusticia.objetos.Juez;
import java.sql.ResultSet;

/**
 * MultiJuez se encarga de enviar consultas SQL a la base de datos (MYSQL), que
 * envian o reciben informacion relacionada con los Jueces.
 *
 * @author Rolando Conejo & Matthew Russell
 * @version 1.0
 */
public class MultiJuez {

    /**
     * Constructor vacio
     */
    public MultiJuez() {
    }

    /**
     * Envia una sentencia DML(INSERT) a la base de datos, para guardar la
     * informacion de un juez.
     *
     * @param cedula
     * @param usuario
     * @param clave
     * @param nombre
     * @param apellidos
     * @param telefono
     * @param sala
     * @throws Exception
     */
    public void guardar(String cedula, String usuario, String clave, String nombre, String apellidos, String telefono, String sala) throws Exception {
        String query;
        query = "INSERT INTO jueces (cedula, usuario, clave, nombre, apellidos, telefono, sala)"
                + "VALUES ('" + cedula + "','" + usuario + "','" + clave + "','" + nombre + "','" + apellidos + "','" + telefono + "','" + sala + "');";

        try {
            Conector.getConector().ejecutarSQL(query);

        } catch (Exception e) {
            throw e;
        }

    }

    /**
     * Envia una consulta SQL a la base de datos, para verificar si en la tabla
     * jueces se encuentra un juez que se identifique con la cedula enviada como
     * parametro.
     *
     * @param cedula
     * @return existe
     * @throws Exception
     */
    public boolean comprobarRegistro(String cedula) throws Exception {
        ResultSet rs = null;
        String query;
        boolean existe = false;

        query = "SELECT cedula "
                + "FROM jueces "
                + "WHERE cedula = '" + cedula + "';";

        try {
            rs = Conector.getConector().ejecutarSQL(query, true);

            if (rs.next()) {
                existe = true;
            }

            rs.close();
//            Conector.getConector().cerrarConexion();

        } catch (Exception e) {
            throw e;
        }

        return existe;
    }

    /**
     * Envia una consulta SQL a la base de datos, para verificar si en la tabla
     * jueces se encuentra un juez que se identifique con el nombre de usuario
     * enviado como parametro.
     *
     * @param usuario
     * @return existe
     * @throws Exception
     */
    public boolean comprobarUsuario(String usuario) throws Exception {
        ResultSet rs = null;
        String query;
        boolean existe = false;

        query = "SELECT usuario "
                + "FROM jueces "
                + "WHERE usuario = '" + usuario + "';";

        try {
            rs = Conector.getConector().ejecutarSQL(query, true);

            if (rs.next()) {
                existe = true;
            }

            rs.close();
//            Conector.getConector().cerrarConexion();

        } catch (Exception e) {
            throw e;
        }

        return existe;
    }

    /**
     * Envia una consulta SQL a la base de datos, para verificar si en la tabla
     * jueces se encuentra un juez que se identifique con el usuario y la clave
     * enviadas como parametro.
     *
     * @param usuario
     * @param clave
     * @return existe
     * @throws Exception
     */
    public boolean verificarDatosLogin(String usuario, String clave) throws Exception {
        ResultSet rs = null;
        String query;
        boolean existe = false;

        query = "SELECT cedula "
                + "FROM jueces "
                + "WHERE usuario = '" + usuario + "' AND clave = '" + clave + "';";

        try {
            rs = Conector.getConector().ejecutarSQL(query, true);

            if (rs.next()) {
//                this.cedulaJuez = rs.getString("cedula");
                actulizarUsuario(rs.getString("cedula"));
                existe = true;
            }

            rs.close();

        } catch (Exception e) {
            throw e;
        }

        return existe;
    }

    /**
     * Envia una consulta SQL a la base de datos, para buscar los datos del juez
     * que esta en sesion.
     *
     * @return tmpJuez instancia de la clase Juez
     * @throws java.sql.SQLException
     * @throws Exception
     */
    public Juez buscar() throws java.sql.SQLException, Exception {
        Juez tmpJuez = null;
        java.sql.ResultSet rs;
        String query, cedula;

        try {
            cedula = buscarUsuario();

            query = "SELECT * "
                    + "FROM jueces "
                    + "WHERE cedula='" + cedula + "';";

            rs = Conector.getConector().ejecutarSQL(query, true);

            if (rs.next()) {
                tmpJuez = new Juez(
                        rs.getString("cedula"),
                        rs.getString("usuario"),
                        rs.getString("clave"),
                        rs.getString("sala"),
                        rs.getString("nombre"),
                        rs.getString("apellidos"),
                        rs.getString("telefono"));
            }

            rs.close();
//            Conector.getConector().cerrarConexion();

        } catch (Exception e) {
            throw e;
        }

        return tmpJuez;
    }

    /**
     * Envia una consulta SQL a la base de datos, para actualizar el usuario que
     * esta en sesion en el momento de usar la aplicacion.
     *
     * @param cedula
     * @throws Exception
     */
    private void actulizarUsuario(String cedula) throws Exception {

        String query;

        query = "UPDATE usuarioycasoactual "
                + "SET id = '" + cedula + "';";
        try {
            Conector.getConector().ejecutarSQL(query);

        } catch (Exception e) {
            throw e;
        }

    }

    /**
     * Envia una consulta SQL a la base de datos, para buscar el usuario que
     * esta en sesion en el momento de usar la aplicacion.
     *
     * @return cedula
     * @throws Exception
     */
    private String buscarUsuario() throws Exception {
        ResultSet rs;
        String cedula = "";
        String query;
        query = "SELECT id "
                + "FROM usuarioycasoactual";

        try {
            rs = Conector.getConector().ejecutarSQL(query, true);

            if (rs.next()) {
                cedula = rs.getString("id");
            }

        } catch (Exception e) {
            throw e;
        }

        return cedula;

    }

}
