package cr.ac.ucenfotec.corteJusticia.objetos;

import java.time.LocalDateTime;

/**
 * Esta clase contiene los metodos y atributos de cada HistorialCaso.
 *
 * @author Rolando Conejo & Matthew Russell
 * @version 1.0
 */
public class HistorialCaso {

    private Caso numeroCaso;
    private String estado;
    private LocalDateTime fecha;

    /**
     * Constructor vacio.
     */
    public HistorialCaso() {
    }

    /**
     * Constructor que recibe los parametros.
     *
     * @param numeroCaso
     * @param estado
     * @param fecha
     */
    public HistorialCaso(int numeroCaso, String estado, LocalDateTime fecha) {
        this.numeroCaso = new Caso();
        this.numeroCaso.setNumero(numeroCaso);
        this.estado = estado;
        this.fecha = fecha;
    }

    /**
     * Retorna el numero de caso.
     *
     * @return numeroCaso
     */
    public int getNumeroCaso() {
        return numeroCaso.getNumero();
    }

    /**
     * Recibe el numero de caso.
     *
     * @param numeroCaso
     */
    public void setNumeroCaso(int numeroCaso) {
        this.numeroCaso = new Caso();
        this.numeroCaso.setNumero(numeroCaso);
    }

    /**
     * Retorna el estado.
     *
     * @return estado
     */
    public String getEstados() {
        return estado;
    }

    /**
     * Recibe el estado.
     *
     * @param estado
     */
    public void setEstados(String estado) {
        this.estado = estado;
    }

    /**
     * Retorna la fecha.
     *
     * @return fecha
     */
    public LocalDateTime getFechas() {
        return fecha;
    }

    /**
     * Recibe la fecha.
     *
     * @param fecha
     */
    public void setFechas(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return "HistorialCaso{" + "numeroCaso=" + numeroCaso.getNumero() + ", estados=" + estado + ", fechas=" + fecha + '}';
    }

}
