Para cambiar la conexi�n de acceso a datos, tiene que buscar la carpeta SistemaJuez que esta en la ui, 
una vez ah� abrir el archivo conexion.txt. Tiene que poner en ese archivo sus datos de usuario y contrase�a 
para poder acceder a la base de datos cortejusticia.